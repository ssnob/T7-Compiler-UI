Your gsc files will NOT appear if they arent in the scripts folder

(WORKING EXAMPLE)
c:/gscmenus/default menu/scripts/main.gsc

When Selecting a folder you want to select the Menu folder. Not The scripts folder
In this is example you would select the 3rd section. Which would be "default menu"

Your gsc files CANNOT be in subfolders. They must all be in the scripts directory. 
I will add something to utomatically do this.